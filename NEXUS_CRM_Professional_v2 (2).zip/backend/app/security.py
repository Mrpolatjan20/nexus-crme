import jwt
from datetime import datetime,timedelta,timezone
from pwdlib import PasswordHash
from fastapi import Depends,HTTPException
from fastapi.security import HTTPBearer,HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from .config import settings
from .db import get_db
from .models import User
ph=PasswordHash.recommended()
bearer=HTTPBearer()
def hash_password(p): return ph.hash(p)
def verify_password(p,h): return ph.verify(p,h)
def token_for(u):
    exp=datetime.now(timezone.utc)+timedelta(minutes=settings.access_token_minutes)
    return jwt.encode({"sub":str(u.id),"role":u.role,"exp":exp},settings.secret_key,algorithm="HS256")
def current_user(c:HTTPAuthorizationCredentials=Depends(bearer),db:Session=Depends(get_db)):
    try:
        d=jwt.decode(c.credentials,settings.secret_key,algorithms=["HS256"])
        u=db.get(User,int(d["sub"]))
        if not u or not u.is_active: raise ValueError()
        return u
    except Exception: raise HTTPException(401,"Sessiya yaroqsiz yoki muddati tugagan")
def roles(*allowed):
    def check(u:User=Depends(current_user)):
        if u.role not in allowed: raise HTTPException(403,"Huquq yetarli emas")
        return u
    return check
