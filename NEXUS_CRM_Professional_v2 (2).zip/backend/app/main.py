from contextlib import asynccontextmanager
from fastapi import FastAPI,Depends,HTTPException
from pydantic import BaseModel,Field
from sqlalchemy.orm import Session
from sqlalchemy import select
from .db import Base,engine,get_db,SessionLocal
from .models import User,Customer,Application,AuditLog
from .security import hash_password,verify_password,token_for,current_user,roles
from .config import settings
@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        if not db.scalar(select(User).where(User.username==settings.admin_username)):
            db.add(User(username=settings.admin_username,full_name="NEXUS Administrator",password_hash=hash_password(settings.admin_password),role="admin")); db.commit()
    yield
app=FastAPI(title="NEXUS CRM API",version="1.0.0",lifespan=lifespan)
class Login(BaseModel):
    username:str
    password:str
class EmployeeIn(BaseModel):
    username:str=Field(min_length=3,max_length=80)
    password:str=Field(min_length=10,max_length=128)
    full_name:str=Field(min_length=3,max_length=180)
    role:str=Field(pattern="^(operator|manager|admin)$")
class CustomerIn(BaseModel):
    full_name:str=Field(min_length=3,max_length=180)
    birth_date:str=Field(pattern=r"^\d{2}\.\d{2}\.\d{4}$")
    passport_number:str=Field(min_length=7,max_length=20)
    pinfl:str=Field(pattern=r"^\d{14}$")
    phone:str=Field(min_length=7,max_length=30)
    address:str=Field(min_length=4,max_length=1000)
class ApplicationIn(BaseModel):
    customer_id:int
    title:str=Field(min_length=3,max_length=180)
    description:str=""
class StatusIn(BaseModel):
    status:str=Field(pattern="^(under_review|approved|rejected)$")
def log(db,u,action,entity,eid="",details=""):
    db.add(AuditLog(user_id=u.id,action=action,entity=entity,entity_id=str(eid),details=details))
@app.get("/health")
def health(): return {"status":"ok","service":"NEXUS CRM API"}
@app.post("/auth/login")
def login(x:Login,db:Session=Depends(get_db)):
    u=db.scalar(select(User).where(User.username==x.username))
    if not u or not u.is_active or not verify_password(x.password,u.password_hash): raise HTTPException(401,"Login yoki parol noto‘g‘ri")
    return {"access_token":token_for(u),"token_type":"bearer","role":u.role,"full_name":u.full_name}
@app.get("/auth/me")
def me(u:User=Depends(current_user)): return {"id":u.id,"username":u.username,"full_name":u.full_name,"role":u.role}
@app.get("/employees")
def employees(db:Session=Depends(get_db),u:User=Depends(roles("admin","manager"))):
    return [{"id":x.id,"username":x.username,"full_name":x.full_name,"role":x.role,"is_active":x.is_active} for x in db.scalars(select(User).order_by(User.id.desc())).all()]
@app.post("/employees")
def add_employee(x:EmployeeIn,db:Session=Depends(get_db),u:User=Depends(roles("admin"))):
    if db.scalar(select(User).where(User.username==x.username)): raise HTTPException(409,"Login band")
    item=User(username=x.username,full_name=x.full_name,password_hash=hash_password(x.password),role=x.role)
    db.add(item); db.flush(); log(db,u,"employee_created","user",item.id,x.role); db.commit()
    return {"id":item.id,"username":item.username,"full_name":item.full_name,"role":item.role}
@app.get("/customers")
def customers(q:str="",db:Session=Depends(get_db),u:User=Depends(current_user)):
    stmt=select(Customer).order_by(Customer.id.desc())
    if q: stmt=stmt.where(Customer.full_name.ilike(f"%{q}%"))
    return [{"id":x.id,"full_name":x.full_name,"birth_date":x.birth_date,"passport_number":x.passport_number,"pinfl":x.pinfl,"phone":x.phone,"address":x.address} for x in db.scalars(stmt.limit(200)).all()]
@app.post("/customers")
def add_customer(x:CustomerIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
    p=x.passport_number.upper().replace(" ","")
    if db.scalar(select(Customer).where((Customer.passport_number==p)|(Customer.pinfl==x.pinfl))): raise HTTPException(409,"Pasport yoki JSHSHIR avval kiritilgan")
    item=Customer(**x.model_dump(exclude={"passport_number"}),passport_number=p,created_by=u.id)
    db.add(item); db.flush(); log(db,u,"customer_created","customer",item.id); db.commit()
    return {"id":item.id,"full_name":item.full_name}
@app.get("/applications")
def applications(db:Session=Depends(get_db),u:User=Depends(current_user)):
    return [{"id":x.id,"customer_id":x.customer_id,"title":x.title,"description":x.description,"status":x.status} for x in db.scalars(select(Application).order_by(Application.id.desc()).limit(200)).all()]
@app.post("/applications")
def add_application(x:ApplicationIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
    if not db.get(Customer,x.customer_id): raise HTTPException(404,"Mijoz topilmadi")
    item=Application(**x.model_dump(),created_by=u.id); db.add(item); db.flush(); log(db,u,"application_created","application",item.id); db.commit()
    return {"id":item.id,"status":item.status}
@app.patch("/applications/{item_id}/status")
def status(item_id:int,x:StatusIn,db:Session=Depends(get_db),u:User=Depends(roles("admin","manager"))):
    item=db.get(Application,item_id)
    if not item: raise HTTPException(404,"Ariza topilmadi")
    item.status=x.status; item.reviewed_by=u.id; log(db,u,"application_status_changed","application",item.id,x.status); db.commit()
    return {"id":item.id,"status":item.status}
@app.get("/audit")
def audit(db:Session=Depends(get_db),u:User=Depends(roles("admin","manager"))):
    return [{"id":x.id,"user_id":x.user_id,"action":x.action,"entity":x.entity,"entity_id":x.entity_id,"details":x.details,"created_at":x.created_at} for x in db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(300)).all()]
