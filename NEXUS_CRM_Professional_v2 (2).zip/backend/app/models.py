from sqlalchemy import String,Integer,DateTime,ForeignKey,Text,func
from sqlalchemy.orm import Mapped,mapped_column
from .db import Base
class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(primary_key=True)
    username:Mapped[str]=mapped_column(String(80),unique=True,index=True)
    full_name:Mapped[str]=mapped_column(String(180))
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(20),default="operator")
    is_active:Mapped[int]=mapped_column(Integer,default=1)
class Customer(Base):
    __tablename__="customers"
    id:Mapped[int]=mapped_column(primary_key=True)
    full_name:Mapped[str]=mapped_column(String(180),index=True)
    birth_date:Mapped[str]=mapped_column(String(10))
    passport_number:Mapped[str]=mapped_column(String(20),unique=True,index=True)
    pinfl:Mapped[str]=mapped_column(String(14),unique=True,index=True)
    phone:Mapped[str]=mapped_column(String(30))
    address:Mapped[str]=mapped_column(Text)
    created_by:Mapped[int]=mapped_column(ForeignKey("users.id"))
    created_at:Mapped[DateTime]=mapped_column(DateTime(timezone=True),server_default=func.now())
class Application(Base):
    __tablename__="applications"
    id:Mapped[int]=mapped_column(primary_key=True)
    customer_id:Mapped[int]=mapped_column(ForeignKey("customers.id"))
    title:Mapped[str]=mapped_column(String(180))
    description:Mapped[str]=mapped_column(Text,default="")
    status:Mapped[str]=mapped_column(String(30),default="new")
    created_by:Mapped[int]=mapped_column(ForeignKey("users.id"))
    reviewed_by:Mapped[int|None]=mapped_column(ForeignKey("users.id"),nullable=True)
    created_at:Mapped[DateTime]=mapped_column(DateTime(timezone=True),server_default=func.now())
class AuditLog(Base):
    __tablename__="audit_logs"
    id:Mapped[int]=mapped_column(primary_key=True)
    user_id:Mapped[int]=mapped_column(ForeignKey("users.id"))
    action:Mapped[str]=mapped_column(String(100))
    entity:Mapped[str]=mapped_column(String(80))
    entity_id:Mapped[str]=mapped_column(String(80),default="")
    details:Mapped[str]=mapped_column(Text,default="")
    created_at:Mapped[DateTime]=mapped_column(DateTime(timezone=True),server_default=func.now())
