package uz.nexus.crm
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
class MainActivity:Activity(){
 private val blue=Color.rgb(22,91,160); private val prefs by lazy{getSharedPreferences("nexus",MODE_PRIVATE)}
 private lateinit var box:LinearLayout; private var token:String?=null
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);token=prefs.getString("token",null);if(token==null)login() else dashboard("Xodim","")}
 private fun page(title:String){box=LinearLayout(this).apply{orientation=1;setPadding(24,28,24,24);setBackgroundColor(Color.rgb(246,249,252))}
 box.addView(TextView(this).apply{text=title;textSize=26f;setTextColor(blue);setTypeface(null,1);setPadding(0,0,0,18)})
 setContentView(ScrollView(this).apply{addView(box)})}
 private fun field(h:String,p:Boolean=false)=EditText(this).apply{hint=h;setSingleLine(true);if(p)inputType=129;box.addView(this)}
 private fun button(s:String,f:()->Unit){box.addView(Button(this).apply{text=s;isAllCaps=false;setTextColor(-1);setBackgroundColor(blue);setOnClickListener{f()}})}
 private fun login(){page("NEXUS CRM");box.addView(TextView(this).apply{text="Korporativ mijozlar boshqaruv tizimi";textSize=14f})
 val u=field("Login");val p=field("Parol",true);val msg=TextView(this);box.addView(msg)
 button("Tizimga kirish"){msg.text="Serverga ulanmoqda...";api("POST","auth/login",JSONObject().put("username",u.text.toString().trim()).put("password",p.text.toString()),null){c,r->runOnUiThread{if(c in 200..299){val j=JSONObject(r);token=j.getString("access_token");prefs.edit().putString("token",token).apply();dashboard(j.optString("full_name"),j.optString("role"))}else msg.text="Xato ($c): $r"}}}
 }
 private fun dashboard(name:String,role:String){page("NEXUS CRM");box.addView(TextView(this).apply{text="Xush kelibsiz, $name\\nRol: $role";textSize=16f})
 button("Mijozlar"){list("Mijozlar","customers")};button("Arizalar"){list("Arizalar","applications")}
 if(role=="admin"||role=="manager")button("Xodimlar"){list("Xodimlar","employees")}
 button("Chiqish"){token=null;prefs.edit().remove("token").apply();login()}
 }
 private fun list(title:String,path:String){page(title);val t=TextView(this).apply{text="Yuklanmoqda...";textSize=15f};box.addView(t)
 api("GET",path,null,token){c,r->runOnUiThread{t.text=if(c in 200..299)r else "Server xatosi ($c): $r"}}
 button("Orqaga"){dashboard("Xodim","")}
 }
 private fun api(method:String,path:String,data:JSONObject?,auth:String?,done:(Int,String)->Unit){thread{var con:HttpURLConnection?=null;try{
 val base=BuildConfig.API_BASE_URL.trimEnd('/')+"/";if(base.contains("YOUR_DOMAIN"))throw Exception("API_BASE_URL server domeniga almashtirilmagan")
 con=(URL(base+path).openConnection() as HttpURLConnection).apply{requestMethod=method;connectTimeout=15000;readTimeout=15000;setRequestProperty("Accept","application/json");if(data!=null){doOutput=true;setRequestProperty("Content-Type","application/json")};if(auth!=null)setRequestProperty("Authorization","Bearer $auth")}
 if(data!=null)con.outputStream.use{it.write(data.toString().toByteArray())};val code=con.responseCode;val stream=if(code<400)con.inputStream else con.errorStream;val response=stream?.bufferedReader()?.use{it.readText()}?:"";done(code,response)
 }catch(e:Exception){done(-1,e.message?:"Ulanish xatosi")}finally{con?.disconnect()}}}
}
