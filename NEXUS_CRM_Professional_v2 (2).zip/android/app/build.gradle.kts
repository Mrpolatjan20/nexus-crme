plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="uz.nexus.crm"
    compileSdk=35
    defaultConfig {
        applicationId="uz.nexus.crm"; minSdk=26; targetSdk=35
        versionCode=2; versionName="2.0.0"
        buildConfigField("String","API_BASE_URL","\"https://YOUR_DOMAIN/\"")
    }
    buildFeatures { buildConfig=true }
    compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget="17" }
}
