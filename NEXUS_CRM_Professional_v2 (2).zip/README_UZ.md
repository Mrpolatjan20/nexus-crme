# NEXUS CRM Professional Starter
Android + FastAPI + PostgreSQL.

## Server
1. Copy `.env.example` to `.env`.
2. Replace all CHANGE_ME values with strong unique secrets.
3. Run `docker compose up -d --build`.
4. Check `http://SERVER_IP:8000/health` and API docs at `/docs`.
5. For public production use, configure a domain, HTTPS reverse proxy, firewall, backups and encrypted sensitive fields before entering real customer data.

## Android
Set `API_BASE_URL` in `android/app/build.gradle.kts` to your HTTPS API URL, e.g. `https://crm.example.uz/`, then build using Android Studio or GitHub Actions.

## First admin
Created on first server start using ADMIN_USERNAME and ADMIN_PASSWORD from `.env`.

## Implemented API
JWT login, role-based access, employees, customers with duplicate passport/PINFL checks, applications/status approval, audit log.
Roles: operator, manager, admin. Only admin creates employees; manager/admin review applications.

## Not yet implemented
Camera/photo storage, chat, push notifications, PDF/Excel, KPI, complete translations. MyID is not integrated. This is a secure-minded MVP foundation, not yet production-certified. Do not enter real passport/PINFL/face data until HTTPS, encryption-at-rest, consent, backups and security review are completed. Format checks do not prove document authenticity.
