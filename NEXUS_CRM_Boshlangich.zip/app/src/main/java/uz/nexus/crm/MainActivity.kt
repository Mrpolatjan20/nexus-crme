package uz.nexus.crm

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val blue = Color.rgb(23, 105, 170)
    private val prefs by lazy { getSharedPreferences("nexus_local", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var role = "Operator"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(Color.rgb(246, 249, 252))
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(blue)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 18)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(heading)
        setContentView(root)
    }

    private fun field(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
        return EditText(this).apply {
            this.hint = hint
            inputType = type
            textSize = 16f
            setSingleLine(true)
            setPadding(14, 8, 14, 8)
            background = getDrawable(android.R.drawable.edit_text)
        }
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 7, 0, 7)
        root.addView(b, p)
    }

    private fun showLogin() {
        base("NEXUS CRM")
        root.addView(TextView(this).apply {
            text = "Mijozlar va arizalarni boshqarish tizimi"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })
        val user = field("Login")
        val pass = field("Parol", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        root.addView(user); root.addView(pass)
        button("Kirish") {
            val u = user.text.toString().trim().lowercase()
            val p = pass.text.toString()
            role = when {
                u == "admin" && p == "123456" -> "Administrator"
                u == "manager" && p == "123456" -> "Manager"
                u == "operator" && p == "123456" -> "Operator"
                else -> ""
            }
            if (role.isEmpty()) toast("Login yoki parol noto‘g‘ri")
            else showDashboard()
        }
        root.addView(TextView(this).apply {
            text = "Sinov kirishlari: admin / manager / operator\nParol: 123456"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 18, 0, 0)
        })
    }

    private fun showDashboard() {
        base("NEXUS CRM")
        root.addView(TextView(this).apply {
            text = "Boshqaruv paneli  •  $role"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 12)
        })
        button("Mijozlar") { showCustomers() }
        button("Yangi mijoz qo‘shish") { showCustomerForm() }
        button("Arizalar") { showApplications() }
        if (role != "Operator") button("Xodimlar boshqaruvi") { showEmployees() }
        if (role == "Administrator") button("Tizim boshqaruvi") {
            toast("Administrator huquqlari faol")
        }
        button("Chiqish") { showLogin() }
    }

    private fun customerArray(): JSONArray =
        try { JSONArray(prefs.getString("customers", "[]")) } catch (_: Exception) { JSONArray() }

    private fun showCustomers() {
        base("Mijozlar")
        val arr = customerArray()
        if (arr.length() == 0) {
            root.addView(TextView(this).apply { text = "Hozircha mijozlar yo‘q."; textSize = 16f })
        } else {
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                root.addView(TextView(this).apply {
                    text = "${c.optString("name")}\n${c.optString("phone")}  •  ${c.optString("passport")}"
                    textSize = 15f
                    setTextColor(Color.DKGRAY)
                    setPadding(12, 12, 12, 12)
                    setBackgroundColor(Color.WHITE)
                })
            }
        }
        button("Orqaga") { showDashboard() }
    }

    private fun showCustomerForm() {
        base("Yangi mijoz")
        val name = field("F.I.Sh.")
        val birth = field("Tug‘ilgan sana (KK.OO.YYYY)")
        val passport = field("Pasport/ID seriya va raqami")
        val pinfl = field("JSHSHIR — 14 raqam", InputType.TYPE_CLASS_NUMBER)
        val phone = field("Telefon raqami", InputType.TYPE_CLASS_PHONE)
        val address = field("Yashash manzili")
        listOf(name, birth, passport, pinfl, phone, address).forEach { root.addView(it) }
        root.addView(TextView(this).apply {
            text = "Yuz surati: ushbu boshlang‘ich versiyada kamera va xavfsiz fayl saqlash keyingi bosqichda ulanadi. Mijoz roziligisiz suratga olmang."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 10, 0, 10)
        })
        button("Mijozni saqlash") {
            val n = name.text.toString().trim()
            val ps = passport.text.toString().trim().uppercase()
            val pn = pinfl.text.toString().trim()
            if (n.isEmpty() || birth.text.isNullOrBlank() || ps.isEmpty() ||
                pn.length != 14 || phone.text.isNullOrBlank() || address.text.isNullOrBlank()) {
                toast("Barcha maydonlarni to‘ldiring. JSHSHIR 14 raqam bo‘lishi kerak.")
                return@button
            }
            val arr = customerArray()
            for (i in 0 until arr.length()) {
                val old = arr.getJSONObject(i)
                if (old.optString("passport") == ps || old.optString("pinfl") == pn) {
                    toast("Bu pasport yoki JSHSHIR avval kiritilgan")
                    return@button
                }
            }
            arr.put(JSONObject().apply {
                put("name", n); put("birth", birth.text.toString().trim())
                put("passport", ps); put("pinfl", pn)
                put("phone", phone.text.toString().trim())
                put("address", address.text.toString().trim())
                put("createdBy", role); put("createdAt", System.currentTimeMillis())
            })
            prefs.edit().putString("customers", arr.toString()).apply()
            toast("Mijoz saqlandi")
            showCustomers()
        }
        button("Bekor qilish") { showDashboard() }
    }

    private fun showApplications() {
        base("Arizalar")
        root.addView(TextView(this).apply {
            text = "Arizalar bo‘limi tayyorlanmoqda. Keyingi bosqichda ariza holatlari, tasdiqlash va rad etish serverga ulanadi."
            textSize = 15f
            setTextColor(Color.DKGRAY)
        })
        button("Orqaga") { showDashboard() }
    }

    private fun showEmployees() {
        base("Xodimlar")
        root.addView(TextView(this).apply {
            text = "Manager va Administrator xodimlar bo‘limiga kira oladi.\n\nHozirgi sinov rollari:\nadmin — Administrator\nmanager — Manager\noperator — Operator\nParol: 123456\n\nDoimiy xodim yaratish va serverdagi huquqlar keyingi backend bosqichida ulanadi."
            textSize = 15f
            setTextColor(Color.DKGRAY)
        })
        button("Orqaga") { showDashboard() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
