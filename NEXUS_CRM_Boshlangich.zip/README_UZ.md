# NEXUS CRM — boshlang‘ich Android loyiha

## Build
GitHub repository rootiga ushbu ZIP ichidagi fayllarni joylang. GitHub → Actions → Build NEXUS CRM APK → Run workflow.

APK `NEXUS-CRM-debug` nomli artifact sifatida chiqadi.

## Sinov kirishlari
- admin / 123456
- manager / 123456
- operator / 123456

## Hozir ishlaydigan qismlar
- Rolga qarab kirish (demo)
- Boshqaruv paneli
- Mijoz qo‘shish
- F.I.Sh., tug‘ilgan sana, pasport/ID, JSHSHIR, telefon, manzilni tekshirish
- JSHSHIR 14 raqamligini tekshirish
- Takroriy pasport/JSHSHIRni bloklash
- Mijozlarni qurilmada ko‘rish

## Hali ulanmagan qismlar
Yuz suratini olish, server/API, haqiqiy xodim yaratish, arizalarni tasdiqlash, KPI, bildirishnoma, audit, chat, PDF/Excel va ko‘p qurilmali sinxronlash hali ishlab chiqilmagan. Bu ZIP ularning boshlang‘ich karkasi emas, balki ishlaydigan kichik MVP; keyingi bosqichlarda qo‘shiladi.

## Xavfsizlik
Bu demo mahalliy qurilmada sinov uchun. Haqiqiy mijoz pasporti, JSHSHIR yoki yuz suratlarini real foydalanishda kiritmang. Hozircha server darajasidagi autentifikatsiya, shifrlash, audit va rozilik boshqaruvi yo‘q. Sinov parollarini real tizimda ishlatmang.
